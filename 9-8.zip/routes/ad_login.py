from flask import Blueprint, render_template, request, current_app, jsonify
from flask import redirect, url_for, flash
from werkzeug.utils import secure_filename
from docx_reader_math import (read_questions_from_docx, InvalidDocxFile, FileLockedError, XMLParseError)
from datetime import datetime
import os, sqlite3, json
import random, glob
import string
from flask import Flask, render_template, request, redirect, url_for, flash, session
from werkzeug.security import check_password_hash, generate_password_hash

ad_login_bp = Blueprint('ad_login', __name__)


# VALID_USERS = {
#     "admin": "123456",
#     "teacher": "giaovien"
# }

# @ad_login_bp.route('/admincp', methods=['GET', 'POST'])
# def login():
#     if request.method == 'POST':
#         username = request.form.get('username')
#         password = request.form.get('password')
#         if username in VALID_USERS and VALID_USERS[username] == password:
#             session['username'] = username
#             flash('Đăng nhập thành công!', 'success')
#             return redirect(url_for('upload.danh_sach_de_thi'))
#         else:
#             flash('Sai tên đăng nhập hoặc mật khẩu.', 'error')
#     return render_template('login.html')

@ad_login_bp.route('/admincp', methods=['GET', 'POST'])
def login():
    user_st = session.get("status", 1)
    username = session.get("username","Ẩn Danh")
    if user_st == 2:        
        return render_template('ad_quanli_dethi.html', username=username)
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Kết nối CSDL
        conn = sqlite3.connect('student_info.db')
        c = conn.cursor()
        c.execute("SELECT id, username, password, name, school, sdt, status FROM teachers WHERE username = ?", (username,))
        user = c.fetchone()
        conn.close()

        if user:
            user_id, username_db, hashed_pw, name, school, sdt, status = user

            # Kiểm tra trạng thái
            if status != 2:
                flash("Tài khoản của bạn đang bị khóa hoặc không là admin.", "error")
                return redirect(url_for('ad_login.login'))

            # Kiểm tra mật khẩu
            if check_password_hash(hashed_pw, password):
                # Lưu session
                session['user_id'] = user_id
                session['username'] = username_db
                session['name'] = name
                session['school'] = school
                session['status'] = status

                flash("Đăng nhập thành công!", "success")
                # return redirect(url_for('upload.danh_sach_de_thi'))  # Hoặc route bạn muốn
                return render_template('ad_quanli_dethi.html', username=username)
            else:
                flash("Sai mật khẩu.", "error")
        else:
            flash("Tài khoản không tồn tại.", "error")

    return render_template('ad_login.html')


@ad_login_bp.route('/ad_logout')
def logout():
    session.clear()
    flash("Bạn đã đăng xuất!", "success")
    return redirect(url_for('ad_login.login'))

@ad_login_bp.route('/create_super_admin')
def create_super_admin():
    username = 'admin'
    password = 'qui03048'
    hashed_pw = generate_password_hash(password)

    name = 'Super Admin(LNQ)'
    school = 'THPT Châu Văn Liêm'
    sdt = '0982203048'
    status = 2  # super_admin
    re_pw = 0

    conn = sqlite3.connect('student_info.db')
    c = conn.cursor()

    # Kiểm tra nếu username đã tồn tại
    c.execute("DELETE FROM teachers WHERE username = ?", (username,))
    # Thêm tài khoản mới
    c.execute('''
        INSERT INTO teachers (id, username, password, name, school, sdt, status, re_pw)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (1,username, hashed_pw, name, school, sdt, status,re_pw))
    conn.commit()
    conn.close()

    flash("Tài khoản super_admin đã được tạo lại!", "success")
    return redirect(url_for('ad_login.login'))